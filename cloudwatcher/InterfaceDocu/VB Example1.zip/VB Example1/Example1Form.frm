VERSION 5.00
Begin VB.Form Example1Form 
   Caption         =   "Inter program protocol"
   ClientHeight    =   7185
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   13650
   LinkTopic       =   "Form1"
   ScaleHeight     =   7185
   ScaleWidth      =   13650
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command7 
      Caption         =   "Get all"
      Height          =   315
      Left            =   5040
      TabIndex        =   169
      Top             =   240
      Width           =   1515
   End
   Begin VB.CommandButton StopAlarm 
      Caption         =   "Stop"
      Height          =   255
      Left            =   12960
      TabIndex        =   168
      Top             =   1320
      Width           =   585
   End
   Begin VB.CommandButton PlayAlarm 
      Caption         =   "Play"
      Height          =   255
      Index           =   8
      Left            =   12990
      TabIndex        =   167
      Top             =   4320
      Width           =   585
   End
   Begin VB.CommandButton PlayAlarm 
      Caption         =   "Play"
      Height          =   255
      Index           =   7
      Left            =   12990
      TabIndex        =   166
      Top             =   3960
      Width           =   585
   End
   Begin VB.CommandButton PlayAlarm 
      Caption         =   "Play"
      Height          =   255
      Index           =   6
      Left            =   12990
      TabIndex        =   165
      Top             =   3630
      Width           =   585
   End
   Begin VB.CommandButton PlayAlarm 
      Caption         =   "Play"
      Height          =   255
      Index           =   5
      Left            =   12990
      TabIndex        =   164
      Top             =   3300
      Width           =   585
   End
   Begin VB.CommandButton PlayAlarm 
      Caption         =   "Play"
      Height          =   255
      Index           =   4
      Left            =   12990
      TabIndex        =   163
      Top             =   2970
      Width           =   585
   End
   Begin VB.CommandButton PlayAlarm 
      Caption         =   "Play"
      Height          =   255
      Index           =   3
      Left            =   12990
      TabIndex        =   162
      Top             =   2610
      Width           =   585
   End
   Begin VB.CommandButton PlayAlarm 
      Caption         =   "Play"
      Height          =   255
      Index           =   2
      Left            =   12990
      TabIndex        =   161
      Top             =   2280
      Width           =   585
   End
   Begin VB.CommandButton PlayAlarm 
      Caption         =   "Play"
      Height          =   255
      Index           =   1
      Left            =   12990
      TabIndex        =   160
      Top             =   1950
      Width           =   585
   End
   Begin VB.CommandButton PlayAlarm 
      Caption         =   "Play"
      Height          =   255
      Index           =   0
      Left            =   12990
      TabIndex        =   159
      Top             =   1620
      Width           =   585
   End
   Begin VB.CheckBox CheckAlarm 
      Caption         =   "CheckVal"
      Height          =   225
      Index           =   8
      Left            =   7890
      TabIndex        =   146
      Top             =   4290
      Width           =   225
   End
   Begin VB.TextBox SoundDesc 
      Height          =   285
      Index           =   8
      Left            =   8820
      TabIndex        =   145
      Top             =   4290
      Width           =   4095
   End
   Begin VB.CheckBox CheckSafe 
      Caption         =   "CheckVal"
      Height          =   225
      Index           =   8
      Left            =   7620
      TabIndex        =   144
      Top             =   4290
      Width           =   225
   End
   Begin VB.CommandButton SafeGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   8
      Left            =   7020
      TabIndex        =   143
      Top             =   4260
      Width           =   495
   End
   Begin VB.CommandButton SafeSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   8
      Left            =   8190
      TabIndex        =   142
      Top             =   4260
      Width           =   495
   End
   Begin VB.CheckBox CheckAlarm 
      Caption         =   "CheckVal"
      Height          =   225
      Index           =   7
      Left            =   7890
      TabIndex        =   141
      Top             =   3960
      Width           =   225
   End
   Begin VB.TextBox SoundDesc 
      Height          =   285
      Index           =   7
      Left            =   8820
      TabIndex        =   140
      Top             =   3960
      Width           =   4095
   End
   Begin VB.CheckBox CheckSafe 
      Caption         =   "CheckVal"
      Height          =   225
      Index           =   7
      Left            =   7620
      TabIndex        =   139
      Top             =   3960
      Width           =   225
   End
   Begin VB.CommandButton SafeGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   7
      Left            =   7020
      TabIndex        =   138
      Top             =   3930
      Width           =   495
   End
   Begin VB.CommandButton SafeSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   7
      Left            =   8190
      TabIndex        =   137
      Top             =   3930
      Width           =   495
   End
   Begin VB.CheckBox CheckAlarm 
      Caption         =   "CheckVal"
      Height          =   225
      Index           =   6
      Left            =   7890
      TabIndex        =   136
      Top             =   3630
      Width           =   225
   End
   Begin VB.TextBox SoundDesc 
      Height          =   285
      Index           =   6
      Left            =   8820
      TabIndex        =   135
      Top             =   3630
      Width           =   4095
   End
   Begin VB.CommandButton SafeSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   6
      Left            =   8190
      TabIndex        =   134
      Top             =   3600
      Width           =   495
   End
   Begin VB.CommandButton SafeGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   6
      Left            =   7020
      TabIndex        =   133
      Top             =   3600
      Width           =   495
   End
   Begin VB.CheckBox CheckSafe 
      Caption         =   "CheckVal"
      Height          =   225
      Index           =   6
      Left            =   7620
      TabIndex        =   132
      Top             =   3630
      Width           =   225
   End
   Begin VB.CheckBox CheckSafe 
      Caption         =   "CheckVal"
      Height          =   225
      Index           =   3
      Left            =   7620
      TabIndex        =   128
      Top             =   2610
      Width           =   225
   End
   Begin VB.CommandButton SafeGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   3
      Left            =   7020
      TabIndex        =   127
      Top             =   2580
      Width           =   495
   End
   Begin VB.CommandButton SafeSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   3
      Left            =   8190
      TabIndex        =   126
      Top             =   2580
      Width           =   495
   End
   Begin VB.TextBox SoundDesc 
      Height          =   285
      Index           =   3
      Left            =   8820
      TabIndex        =   125
      Top             =   2610
      Width           =   4095
   End
   Begin VB.CheckBox CheckAlarm 
      Caption         =   "CheckVal"
      Height          =   225
      Index           =   3
      Left            =   7890
      TabIndex        =   124
      Top             =   2610
      Width           =   225
   End
   Begin VB.CommandButton SafeSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   4
      Left            =   8190
      TabIndex        =   123
      Top             =   2910
      Width           =   495
   End
   Begin VB.CommandButton SafeGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   4
      Left            =   7020
      TabIndex        =   122
      Top             =   2910
      Width           =   495
   End
   Begin VB.CheckBox CheckSafe 
      Caption         =   "CheckVal"
      Height          =   225
      Index           =   4
      Left            =   7620
      TabIndex        =   121
      Top             =   2940
      Width           =   225
   End
   Begin VB.TextBox SoundDesc 
      Height          =   285
      Index           =   4
      Left            =   8820
      TabIndex        =   120
      Top             =   2940
      Width           =   4095
   End
   Begin VB.CheckBox CheckAlarm 
      Caption         =   "CheckVal"
      Height          =   225
      Index           =   4
      Left            =   7890
      TabIndex        =   119
      Top             =   2940
      Width           =   225
   End
   Begin VB.CommandButton SafeSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   5
      Left            =   8190
      TabIndex        =   118
      Top             =   3240
      Width           =   495
   End
   Begin VB.CommandButton SafeGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   5
      Left            =   7020
      TabIndex        =   117
      Top             =   3240
      Width           =   495
   End
   Begin VB.CheckBox CheckSafe 
      Caption         =   "CheckVal"
      Height          =   225
      Index           =   5
      Left            =   7620
      TabIndex        =   116
      Top             =   3270
      Width           =   225
   End
   Begin VB.TextBox SoundDesc 
      Height          =   285
      Index           =   5
      Left            =   8850
      TabIndex        =   115
      Top             =   3270
      Width           =   4095
   End
   Begin VB.CheckBox CheckAlarm 
      Caption         =   "CheckVal"
      Height          =   225
      Index           =   5
      Left            =   7890
      TabIndex        =   114
      Top             =   3270
      Width           =   225
   End
   Begin VB.CheckBox CheckAlarm 
      Caption         =   "CheckVal"
      Height          =   225
      Index           =   2
      Left            =   7890
      TabIndex        =   113
      Top             =   2250
      Width           =   225
   End
   Begin VB.TextBox SoundDesc 
      Height          =   285
      Index           =   2
      Left            =   8820
      TabIndex        =   112
      Top             =   2250
      Width           =   4095
   End
   Begin VB.CheckBox CheckSafe 
      Caption         =   "CheckVal"
      Height          =   225
      Index           =   2
      Left            =   7620
      TabIndex        =   110
      Top             =   2250
      Width           =   225
   End
   Begin VB.CommandButton SafeGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   2
      Left            =   7020
      TabIndex        =   109
      Top             =   2220
      Width           =   495
   End
   Begin VB.CommandButton SafeSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   2
      Left            =   8190
      TabIndex        =   108
      Top             =   2220
      Width           =   495
   End
   Begin VB.CheckBox CheckAlarm 
      Caption         =   "CheckVal"
      Height          =   225
      Index           =   1
      Left            =   7890
      TabIndex        =   107
      Top             =   1920
      Width           =   225
   End
   Begin VB.TextBox SoundDesc 
      Height          =   285
      Index           =   1
      Left            =   8820
      TabIndex        =   106
      Top             =   1920
      Width           =   4095
   End
   Begin VB.CheckBox CheckSafe 
      Caption         =   "CheckVal"
      Height          =   225
      Index           =   1
      Left            =   7620
      TabIndex        =   104
      Top             =   1920
      Width           =   225
   End
   Begin VB.CommandButton SafeGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   1
      Left            =   7020
      TabIndex        =   103
      Top             =   1890
      Width           =   495
   End
   Begin VB.CommandButton SafeSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   1
      Left            =   8190
      TabIndex        =   102
      Top             =   1890
      Width           =   495
   End
   Begin VB.CheckBox CheckAlarm 
      Caption         =   "CheckVal"
      Height          =   225
      Index           =   0
      Left            =   7890
      TabIndex        =   101
      Top             =   1590
      Width           =   225
   End
   Begin VB.TextBox SoundDesc 
      Height          =   285
      Index           =   0
      Left            =   8820
      TabIndex        =   100
      Top             =   1590
      Width           =   4095
   End
   Begin VB.CommandButton SafeSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   0
      Left            =   8190
      TabIndex        =   98
      Top             =   1560
      Width           =   495
   End
   Begin VB.CommandButton SafeGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   0
      Left            =   7020
      TabIndex        =   97
      Top             =   1560
      Width           =   495
   End
   Begin VB.CheckBox CheckSafe 
      Caption         =   "CheckVal"
      Height          =   225
      Index           =   0
      Left            =   7620
      TabIndex        =   96
      Top             =   1590
      Width           =   225
   End
   Begin VB.CheckBox Check2 
      Caption         =   "Temp.Factor OFF"
      Height          =   285
      Left            =   6000
      Style           =   1  'Graphical
      TabIndex        =   95
      Top             =   5040
      Width           =   2115
   End
   Begin VB.CommandButton LimitGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   19
      Left            =   7080
      TabIndex        =   93
      Top             =   6750
      Width           =   495
   End
   Begin VB.TextBox LimVal 
      Height          =   285
      Index           =   19
      Left            =   7590
      TabIndex        =   92
      Top             =   6780
      Width           =   645
   End
   Begin VB.CommandButton LimitSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   19
      Left            =   8250
      TabIndex        =   91
      Top             =   6750
      Width           =   495
   End
   Begin VB.CommandButton LimitGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   18
      Left            =   7080
      TabIndex        =   89
      Top             =   6420
      Width           =   495
   End
   Begin VB.TextBox LimVal 
      Height          =   285
      Index           =   18
      Left            =   7590
      TabIndex        =   88
      Top             =   6450
      Width           =   645
   End
   Begin VB.CommandButton LimitSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   18
      Left            =   8250
      TabIndex        =   87
      Top             =   6420
      Width           =   495
   End
   Begin VB.CommandButton LimitGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   17
      Left            =   7080
      TabIndex        =   85
      Top             =   6090
      Width           =   495
   End
   Begin VB.TextBox LimVal 
      Height          =   285
      Index           =   17
      Left            =   7590
      TabIndex        =   84
      Top             =   6120
      Width           =   645
   End
   Begin VB.CommandButton LimitSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   17
      Left            =   8250
      TabIndex        =   83
      Top             =   6090
      Width           =   495
   End
   Begin VB.CommandButton LimitGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   16
      Left            =   7080
      TabIndex        =   81
      Top             =   5760
      Width           =   495
   End
   Begin VB.TextBox LimVal 
      Height          =   285
      Index           =   16
      Left            =   7590
      TabIndex        =   80
      Top             =   5790
      Width           =   645
   End
   Begin VB.CommandButton LimitSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   16
      Left            =   8250
      TabIndex        =   79
      Top             =   5760
      Width           =   495
   End
   Begin VB.CommandButton LimitGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   15
      Left            =   7080
      TabIndex        =   77
      Top             =   5430
      Width           =   495
   End
   Begin VB.TextBox LimVal 
      Height          =   285
      Index           =   15
      Left            =   7590
      TabIndex        =   76
      Top             =   5460
      Width           =   645
   End
   Begin VB.CommandButton LimitSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   15
      Left            =   8250
      TabIndex        =   75
      Top             =   5430
      Width           =   495
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Index           =   8
      Left            =   3540
      TabIndex        =   74
      Top             =   4110
      Width           =   1575
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Index           =   7
      Left            =   3540
      TabIndex        =   73
      Top             =   3780
      Width           =   1575
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Index           =   6
      Left            =   3540
      TabIndex        =   72
      Top             =   3450
      Width           =   1575
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Index           =   5
      Left            =   3540
      TabIndex        =   71
      Top             =   3060
      Width           =   1575
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Index           =   4
      Left            =   3540
      TabIndex        =   70
      Top             =   2730
      Width           =   1575
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Index           =   3
      Left            =   3540
      TabIndex        =   69
      Top             =   2400
      Width           =   1575
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Index           =   2
      Left            =   3540
      TabIndex        =   68
      Top             =   1980
      Width           =   1575
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Index           =   1
      Left            =   3540
      TabIndex        =   67
      Top             =   1650
      Width           =   1575
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Index           =   0
      Left            =   3540
      TabIndex        =   66
      Top             =   1320
      Width           =   1575
   End
   Begin VB.CommandButton Command5 
      Caption         =   "Start"
      Height          =   315
      Left            =   240
      TabIndex        =   50
      Top             =   240
      Width           =   1515
   End
   Begin VB.CheckBox Check1 
      Caption         =   "Check1"
      Height          =   225
      Left            =   2610
      TabIndex        =   49
      Top             =   6750
      Width           =   225
   End
   Begin VB.CommandButton LimitGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   14
      Left            =   1860
      TabIndex        =   48
      Top             =   6720
      Width           =   495
   End
   Begin VB.CommandButton LimitSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   14
      Left            =   3030
      TabIndex        =   47
      Top             =   6720
      Width           =   495
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Window Normal"
      Height          =   315
      Left            =   1830
      TabIndex        =   45
      Top             =   240
      Width           =   1515
   End
   Begin VB.CommandButton LimitSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   13
      Left            =   3030
      TabIndex        =   44
      Top             =   6360
      Width           =   495
   End
   Begin VB.TextBox LimVal 
      Height          =   285
      Index           =   13
      Left            =   2370
      TabIndex        =   43
      Top             =   6360
      Width           =   645
   End
   Begin VB.CommandButton LimitGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   13
      Left            =   1860
      TabIndex        =   42
      Top             =   6330
      Width           =   495
   End
   Begin VB.CommandButton LimitGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   12
      Left            =   1860
      TabIndex        =   41
      Top             =   6000
      Width           =   495
   End
   Begin VB.TextBox LimVal 
      Height          =   285
      Index           =   12
      Left            =   2370
      TabIndex        =   40
      Top             =   6030
      Width           =   645
   End
   Begin VB.CommandButton LimitSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   12
      Left            =   3030
      TabIndex        =   39
      Top             =   6030
      Width           =   495
   End
   Begin VB.CommandButton LimitGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   11
      Left            =   1860
      TabIndex        =   38
      Top             =   5670
      Width           =   495
   End
   Begin VB.TextBox LimVal 
      Height          =   285
      Index           =   11
      Left            =   2370
      TabIndex        =   37
      Top             =   5700
      Width           =   645
   End
   Begin VB.CommandButton LimitSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   11
      Left            =   3030
      TabIndex        =   36
      Top             =   5700
      Width           =   495
   End
   Begin VB.CommandButton LimitGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   10
      Left            =   1860
      TabIndex        =   35
      Top             =   5340
      Width           =   495
   End
   Begin VB.TextBox LimVal 
      Height          =   285
      Index           =   10
      Left            =   2370
      TabIndex        =   34
      Top             =   5370
      Width           =   645
   End
   Begin VB.CommandButton LimitSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   10
      Left            =   3030
      TabIndex        =   33
      Top             =   5340
      Width           =   495
   End
   Begin VB.CommandButton LimitGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   9
      Left            =   1860
      TabIndex        =   32
      Top             =   5010
      Width           =   495
   End
   Begin VB.TextBox LimVal 
      Height          =   285
      Index           =   9
      Left            =   2370
      TabIndex        =   31
      Top             =   5040
      Width           =   645
   End
   Begin VB.CommandButton LimitSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   9
      Left            =   3030
      TabIndex        =   30
      Top             =   5010
      Width           =   495
   End
   Begin VB.CommandButton LimitSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   8
      Left            =   3030
      TabIndex        =   29
      Top             =   4080
      Width           =   495
   End
   Begin VB.TextBox LimVal 
      Height          =   285
      Index           =   8
      Left            =   2370
      TabIndex        =   28
      Top             =   4110
      Width           =   645
   End
   Begin VB.CommandButton LimitGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   8
      Left            =   1860
      TabIndex        =   27
      Top             =   4080
      Width           =   495
   End
   Begin VB.CommandButton LimitSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   7
      Left            =   3030
      TabIndex        =   26
      Top             =   3750
      Width           =   495
   End
   Begin VB.TextBox LimVal 
      Height          =   285
      Index           =   7
      Left            =   2370
      TabIndex        =   25
      Top             =   3780
      Width           =   645
   End
   Begin VB.CommandButton LimitGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   7
      Left            =   1860
      TabIndex        =   24
      Top             =   3750
      Width           =   495
   End
   Begin VB.CommandButton LimitSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   6
      Left            =   3030
      TabIndex        =   23
      Top             =   3420
      Width           =   495
   End
   Begin VB.TextBox LimVal 
      Height          =   285
      Index           =   6
      Left            =   2370
      TabIndex        =   22
      Top             =   3450
      Width           =   645
   End
   Begin VB.CommandButton LimitGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   6
      Left            =   1860
      TabIndex        =   21
      Top             =   3420
      Width           =   495
   End
   Begin VB.CommandButton LimitGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   3
      Left            =   1860
      TabIndex        =   20
      Top             =   2370
      Width           =   495
   End
   Begin VB.TextBox LimVal 
      Height          =   285
      Index           =   3
      Left            =   2370
      TabIndex        =   19
      Top             =   2400
      Width           =   645
   End
   Begin VB.TextBox LimVal 
      Height          =   285
      Index           =   4
      Left            =   2370
      TabIndex        =   18
      Top             =   2730
      Width           =   645
   End
   Begin VB.CommandButton LimitGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   4
      Left            =   1860
      TabIndex        =   17
      Top             =   2700
      Width           =   495
   End
   Begin VB.CommandButton LimitSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   3
      Left            =   3030
      TabIndex        =   16
      Top             =   2370
      Width           =   495
   End
   Begin VB.CommandButton LimitSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   4
      Left            =   3030
      TabIndex        =   15
      Top             =   2700
      Width           =   495
   End
   Begin VB.CommandButton LimitSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   5
      Left            =   3030
      TabIndex        =   14
      Top             =   3030
      Width           =   495
   End
   Begin VB.CommandButton LimitGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   5
      Left            =   1860
      TabIndex        =   13
      Top             =   3030
      Width           =   495
   End
   Begin VB.TextBox LimVal 
      Height          =   285
      Index           =   5
      Left            =   2370
      TabIndex        =   12
      Top             =   3060
      Width           =   645
   End
   Begin VB.TextBox LimVal 
      Height          =   285
      Index           =   2
      Left            =   2370
      TabIndex        =   11
      Top             =   1980
      Width           =   645
   End
   Begin VB.CommandButton LimitGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   2
      Left            =   1860
      TabIndex        =   10
      Top             =   1950
      Width           =   495
   End
   Begin VB.CommandButton LimitSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   2
      Left            =   3030
      TabIndex        =   9
      Top             =   1950
      Width           =   495
   End
   Begin VB.CommandButton LimitSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   1
      Left            =   3030
      TabIndex        =   8
      Top             =   1620
      Width           =   495
   End
   Begin VB.CommandButton LimitSet 
      Caption         =   "Set"
      Height          =   315
      Index           =   0
      Left            =   3030
      TabIndex        =   7
      Top             =   1290
      Width           =   495
   End
   Begin VB.CommandButton LimitGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   1
      Left            =   1860
      TabIndex        =   6
      Top             =   1620
      Width           =   495
   End
   Begin VB.TextBox LimVal 
      Height          =   285
      Index           =   1
      Left            =   2370
      TabIndex        =   5
      Top             =   1650
      Width           =   645
   End
   Begin VB.TextBox LimVal 
      Height          =   285
      Index           =   0
      Left            =   2370
      TabIndex        =   4
      Top             =   1320
      Width           =   645
   End
   Begin VB.CommandButton LimitGet 
      Caption         =   "Get"
      Height          =   315
      Index           =   0
      Left            =   1860
      TabIndex        =   3
      Top             =   1290
      Width           =   495
   End
   Begin VB.CommandButton Command4 
      Caption         =   "Record Stop"
      Height          =   315
      Left            =   3420
      TabIndex        =   2
      Top             =   570
      Width           =   1515
   End
   Begin VB.CommandButton Command3 
      Caption         =   "Record Start"
      Height          =   315
      Left            =   3420
      TabIndex        =   1
      Top             =   240
      Width           =   1515
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Window Minimized"
      Height          =   315
      Left            =   1830
      TabIndex        =   0
      Top             =   570
      Width           =   1515
   End
   Begin VB.CommandButton Command6 
      Caption         =   "Stop"
      Height          =   315
      Left            =   240
      TabIndex        =   51
      Top             =   570
      Width           =   1515
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H00800000&
      Height          =   2175
      Index           =   37
      Left            =   5310
      TabIndex        =   158
      Top             =   4950
      Width           =   8295
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Device section / Setup TAB"
      ForeColor       =   &H00800000&
      Height          =   255
      Index           =   36
      Left            =   5310
      TabIndex        =   157
      Top             =   4710
      Width           =   8295
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H00800000&
      Height          =   3405
      Index           =   33
      Left            =   5310
      TabIndex        =   154
      Top             =   1230
      Width           =   8295
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Unsafe TAB"
      ForeColor       =   &H00800000&
      Height          =   255
      Index           =   32
      Left            =   5310
      TabIndex        =   153
      Top             =   990
      Width           =   8295
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Limits TAB"
      ForeColor       =   &H00800000&
      Height          =   255
      Index           =   30
      Left            =   120
      TabIndex        =   151
      Top             =   990
      Width           =   5085
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Sound Files"
      ForeColor       =   &H80000008&
      Height          =   255
      Index           =   29
      Left            =   8820
      TabIndex        =   150
      Top             =   1320
      Width           =   4095
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Very Light"
      ForeColor       =   &H80000008&
      Height          =   315
      Index           =   28
      Left            =   5370
      TabIndex        =   149
      Top             =   4230
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Light"
      ForeColor       =   &H80000008&
      Height          =   315
      Index           =   27
      Left            =   5370
      TabIndex        =   148
      Top             =   3930
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Dark"
      ForeColor       =   &H80000008&
      Height          =   315
      Index           =   26
      Left            =   5370
      TabIndex        =   147
      Top             =   3630
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Dry"
      ForeColor       =   &H80000008&
      Height          =   315
      Index           =   25
      Left            =   5370
      TabIndex        =   131
      Top             =   2610
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Wet"
      ForeColor       =   &H80000008&
      Height          =   315
      Index           =   24
      Left            =   5370
      TabIndex        =   130
      Top             =   2910
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Rain"
      ForeColor       =   &H80000008&
      Height          =   315
      Index           =   23
      Left            =   5370
      TabIndex        =   129
      Top             =   3210
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Overcast"
      ForeColor       =   &H80000008&
      Height          =   315
      Index           =   22
      Left            =   5370
      TabIndex        =   111
      Top             =   2190
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Cloudy"
      ForeColor       =   &H80000008&
      Height          =   315
      Index           =   21
      Left            =   5370
      TabIndex        =   105
      Top             =   1890
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Clear"
      ForeColor       =   &H80000008&
      Height          =   315
      Index           =   20
      Left            =   5370
      TabIndex        =   99
      Top             =   1590
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Temp.Factor K5"
      ForeColor       =   &H80000008&
      Height          =   345
      Index           =   19
      Left            =   5430
      TabIndex        =   94
      Top             =   6720
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Temp.Factor K4"
      ForeColor       =   &H80000008&
      Height          =   345
      Index           =   18
      Left            =   5430
      TabIndex        =   90
      Top             =   6390
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Temp.Factor K3"
      ForeColor       =   &H80000008&
      Height          =   345
      Index           =   17
      Left            =   5430
      TabIndex        =   86
      Top             =   6060
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Temp.Factor K2"
      ForeColor       =   &H80000008&
      Height          =   345
      Index           =   16
      Left            =   5430
      TabIndex        =   82
      Top             =   5730
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Temp.Factor K1"
      ForeColor       =   &H80000008&
      Height          =   345
      Index           =   15
      Left            =   5430
      TabIndex        =   78
      Top             =   5400
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "UnknownRS232Err"
      ForeColor       =   &H80000008&
      Height          =   345
      Index           =   14
      Left            =   210
      TabIndex        =   65
      Top             =   6300
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "UnknownNoErr"
      ForeColor       =   &H80000008&
      Height          =   345
      Index           =   13
      Left            =   210
      TabIndex        =   64
      Top             =   5970
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "UnknownBrightness"
      ForeColor       =   &H80000008&
      Height          =   345
      Index           =   12
      Left            =   210
      TabIndex        =   63
      Top             =   5640
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "UnknownRain"
      ForeColor       =   &H80000008&
      Height          =   345
      Index           =   11
      Left            =   210
      TabIndex        =   62
      Top             =   5310
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "UnknownCloud"
      ForeColor       =   &H80000008&
      Height          =   345
      Index           =   10
      Left            =   210
      TabIndex        =   61
      Top             =   4980
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "ThreshVLight"
      ForeColor       =   &H80000008&
      Height          =   345
      Index           =   9
      Left            =   210
      TabIndex        =   60
      Top             =   4050
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "ThreshLight"
      ForeColor       =   &H80000008&
      Height          =   345
      Index           =   8
      Left            =   210
      TabIndex        =   59
      Top             =   3720
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "ThreshDark"
      ForeColor       =   &H80000008&
      Height          =   345
      Index           =   3
      Left            =   210
      TabIndex        =   58
      Top             =   3390
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "ThreshRain"
      ForeColor       =   &H80000008&
      Height          =   345
      Index           =   2
      Left            =   210
      TabIndex        =   57
      Top             =   3000
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "ThreshWet"
      ForeColor       =   &H80000008&
      Height          =   345
      Index           =   1
      Left            =   210
      TabIndex        =   56
      Top             =   2670
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "ThreshDry"
      ForeColor       =   &H80000008&
      Height          =   345
      Index           =   0
      Left            =   210
      TabIndex        =   55
      Top             =   2340
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "ThreshTempVCloudy"
      ForeColor       =   &H80000008&
      Height          =   345
      Index           =   7
      Left            =   210
      TabIndex        =   54
      Top             =   1920
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "ThreshTempCloudy"
      ForeColor       =   &H80000008&
      Height          =   345
      Index           =   6
      Left            =   210
      TabIndex        =   53
      Top             =   1590
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "ThreshTempClear"
      ForeColor       =   &H80000008&
      Height          =   345
      Index           =   5
      Left            =   210
      TabIndex        =   52
      Top             =   1260
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Suspend Alarm "
      ForeColor       =   &H80000008&
      Height          =   315
      Index           =   4
      Left            =   210
      TabIndex        =   46
      Top             =   6720
      Width           =   1635
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H00800000&
      Height          =   3405
      Index           =   31
      Left            =   120
      TabIndex        =   152
      Top             =   1230
      Width           =   5085
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H00800000&
      Height          =   2175
      Index           =   35
      Left            =   120
      TabIndex        =   156
      Top             =   4950
      Width           =   5085
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Alarm section / Setup TAB"
      ForeColor       =   &H00800000&
      Height          =   255
      Index           =   34
      Left            =   120
      TabIndex        =   155
      Top             =   4710
      Width           =   5085
   End
End
Attribute VB_Name = "Example1Form"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

' DO NOT FORGET to select AAG_CloudWatcher
'  under menu option Project / References ... of Visual Basic

Dim obj As Object 'AAG_CloudWatcher.CloudWatcher

Private Sub Check2_Click()
  If Me.Check2.Value = 1 Then
    Me.Check2.Caption = "Temp.Factor ON"
    obj.TempFactorON = True
  Else
    Me.Check2.Caption = "Temp.Factor OFF"
    obj.TempFactorON = False
  End If
End Sub

Private Sub Command1_Click()
  obj.WindowNormal
End Sub

Private Sub Command2_Click()
  obj.WindowMinimize
End Sub

Private Sub Command3_Click()
  obj.RecordStart True 'true=appends to file false=clears file
End Sub

Private Sub Command4_Click()
  obj.RecordStop
End Sub

Private Sub Command5_Click()
  obj.Device_Start
End Sub

Private Sub Command6_Click()
  obj.Device_Stop
End Sub

Private Sub Command7_Click()
  Dim i As Long
  For i = 0 To Me.LimitGet.Count - 1
    LimitGet_Click CInt(i)
  Next i
  For i = 0 To Me.SafeGet.Count - 1
    SafeGet_Click CInt(i)
  Next i
  
End Sub

Private Sub Form_Load()
 Set obj = CreateObject("AAG_CloudWatcher.CloudWatcher") 'New AAG_CloudWatcher.CloudWatcher
 Me.Check2.Value = IIf(obj.TempFactorON, 1, 0)
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
  Set obj = Nothing
End Sub

Private Sub LimitGet_Click(Index As Integer)
  Select Case Index
    Case 0
      Me.LimVal(0).Text = obj.ThreshTempClear
      Me.Text1(0).Text = obj.DescriptionClear
      Me.Text1(0).BackColor = obj.ColorClear
    Case 1
      Me.LimVal(1).Text = obj.ThreshTempCloudy
      Me.Text1(1).Text = obj.DescriptionCloudy
      Me.Text1(1).BackColor = obj.ColorCloudy
    Case 2
      Me.LimVal(2).Text = obj.ThreshTempVCloudy
      Me.Text1(2).Text = obj.DescriptionVCloudy
      Me.Text1(2).BackColor = obj.ColorVCloudy
    
    Case 3
      Me.LimVal(3).Text = obj.ThreshRainDry
      Me.Text1(3).Text = obj.DescriptionDry
      Me.Text1(3).BackColor = obj.ColorDry
    Case 4
      Me.LimVal(4).Text = obj.ThreshRainWet
      Me.Text1(4).Text = obj.DescriptionWet
      Me.Text1(4).BackColor = obj.ColorWet
    Case 5
      Me.LimVal(5).Text = obj.ThreshRainRain
      Me.Text1(5).Text = obj.DescriptionRain
      Me.Text1(5).BackColor = obj.ColorRain
    
    Case 6
      Me.LimVal(6).Text = obj.ThreshBrightnessDark
      Me.Text1(6).Text = obj.DescriptionDark
      Me.Text1(6).BackColor = obj.ColorDark
    Case 7
      Me.LimVal(7).Text = obj.ThreshBrightnessLigth
      Me.Text1(7).Text = obj.DescriptionLight
      Me.Text1(7).BackColor = obj.ColorLight
    Case 8
      Me.LimVal(8).Text = obj.ThreshBrightnessVLigth
      Me.Text1(8).Text = obj.DescriptionVLight
      Me.Text1(8).BackColor = obj.ColorVLight
       
    Case 9
      Me.LimVal(9).Text = obj.CloudUnknowConditionValue
    Case 10
      Me.LimVal(10).Text = obj.RainUnknowConditionValue
    Case 11
      Me.LimVal(11).Text = obj.BrightnessUnknowConditionValue
    Case 12
      Me.LimVal(12).Text = obj.NoConsecutiveUnknownReads
    Case 13
      Me.LimVal(13).Text = obj.NoConsecutiveRS232Errors
  
    Case 14
      Me.Check1.Value = obj.AlarmSuspendSound
  
    Case 15
      Me.LimVal(15).Text = obj.TempFactorK1
    Case 16
      Me.LimVal(16).Text = obj.TempFactorK2
    Case 17
      Me.LimVal(17).Text = obj.TempFactorK3
    Case 18
      Me.LimVal(18).Text = obj.TempFactorK4
    Case 19
      Me.LimVal(19).Text = obj.TempFactorK5
  End Select
End Sub

Private Sub LimitSet_Click(Index As Integer)
  Select Case Index
    Case 0
      obj.ThreshTempClear = Val(Me.LimVal(0).Text)
      obj.DescriptionClear = Me.Text1(0).Text
      obj.ColorClear = Me.Text1(0).BackColor
    Case 1
      obj.ThreshTempCloudy = Val(Me.LimVal(1).Text)
      obj.DescriptionCloudy = Me.Text1(1).Text
      obj.ColorCloudy = Me.Text1(1).BackColor
    Case 2
      obj.ThreshTempVCloudy = Val(Me.LimVal(2).Text)
      obj.DescriptionVCloudy = Me.Text1(2).Text
      obj.ColorVCloudy = Me.Text1(2).BackColor
        
    Case 3
      obj.ThreshRainDry = Me.LimVal(3).Text
      obj.DescriptionDry = Me.Text1(3).Text
      obj.ColorDry = Me.Text1(3).BackColor
    Case 4
      obj.ThreshRainWet = Me.LimVal(4).Text
      obj.DescriptionWet = Me.Text1(4).Text
      obj.ColorWet = Me.Text1(4).BackColor
    Case 5
      obj.ThreshRainRain = Me.LimVal(5).Text
      obj.DescriptionRain = Me.Text1(5).Text
      obj.ColorRain = Me.Text1(5).BackColor
      
    Case 6
      obj.ThreshBrightnessDark = Me.LimVal(6).Text
      obj.DescriptionDark = Me.Text1(6).Text
      obj.ColorDark = Me.Text1(6).BackColor
    Case 7
      obj.ThreshBrightnessLigth = Me.LimVal(7).Text
      obj.DescriptionLight = Me.Text1(7).Text
      obj.ColorLight = Me.Text1(7).BackColor
    Case 8
      obj.ThreshBrightnessVLigth = Me.LimVal(8).Text
      obj.DescriptionVLight = Me.Text1(8).Text
      obj.ColorVLight = Me.Text1(8).BackColor
  
    Case 9
      obj.CloudUnknowConditionValue = Me.LimVal(9).Text
    Case 10
      obj.RainUnknowConditionValue = Me.LimVal(10).Text
    Case 11
      obj.BrightnessUnknowConditionValue = Me.LimVal(11).Text
    Case 12
      obj.NoConsecutiveUnknownReads = Me.LimVal(12).Text
      
    Case 13
      obj.NoConsecutiveRS232Errors = Me.LimVal(13).Text
    
    Case 14
      obj.AlarmSuspendSound = Me.Check1.Value
  
    Case 15
      obj.TempFactorK1 = Me.LimVal(15).Text
    Case 16
      obj.TempFactorK2 = Me.LimVal(16).Text
    Case 17
      obj.TempFactorK3 = Me.LimVal(17).Text
    Case 18
      obj.TempFactorK4 = Me.LimVal(18).Text
    Case 19
      obj.TempFactorK5 = Me.LimVal(19).Text
  End Select

End Sub

Private Sub SafeGet_Click(Index As Integer)
  Select Case Index
    Case 0
      Me.CheckSafe(0).Value = obj.SafeClear
      Me.SoundDesc(0).Text = obj.SoundClear
      Me.CheckAlarm(0).Value = obj.AlarmClear
    Case 1
      Me.CheckSafe(1).Value = obj.SafeCloudy
      Me.SoundDesc(1).Text = obj.SoundCloudy
      Me.CheckAlarm(1).Value = obj.AlarmCloudy
    Case 2
      Me.CheckSafe(2).Value = obj.SafeOvercast
      Me.SoundDesc(2).Text = obj.SoundOvercast
      Me.CheckAlarm(2).Value = obj.AlarmOvercast
      
    Case 3
      Me.CheckSafe(3).Value = obj.SafeDry
      Me.SoundDesc(3).Text = obj.SoundDry
      Me.CheckAlarm(3).Value = obj.AlarmDry
    Case 4
      Me.CheckSafe(4).Value = obj.SafeWet
      Me.SoundDesc(4).Text = obj.SoundWet
      Me.CheckAlarm(4).Value = obj.AlarmWet
    Case 5
      Me.CheckSafe(5).Value = obj.SafeRain
      Me.SoundDesc(5).Text = obj.SoundRain
      Me.CheckAlarm(5).Value = obj.AlarmRain
      
    Case 6
      Me.CheckSafe(6).Value = obj.SafeDark
      Me.SoundDesc(6).Text = obj.SoundDark
      Me.CheckAlarm(6).Value = obj.AlarmDark
    Case 7
      Me.CheckSafe(7).Value = obj.SafeLight
      Me.SoundDesc(7).Text = obj.SoundLight
      Me.CheckAlarm(7).Value = obj.AlarmLight
    Case 8
      Me.CheckSafe(8).Value = obj.SafeVLight
      Me.SoundDesc(8).Text = obj.SoundVLight
      Me.CheckAlarm(8).Value = obj.AlarmVLight
      
  End Select
End Sub

Private Sub SafeSet_Click(Index As Integer)
  Select Case Index
    Case 0
      obj.SafeClear = Me.CheckSafe(0).Value
      obj.SoundClear = Me.SoundDesc(0).Text
      obj.AlarmClear = Me.CheckAlarm(0).Value
    Case 1
      obj.SafeCloudy = Me.CheckSafe(1).Value
      obj.SoundCloudy = Me.SoundDesc(1).Text
      obj.AlarmCloudy = Me.CheckAlarm(1).Value
    Case 2
      obj.SafeOvercast = Me.CheckSafe(2).Value
      obj.SoundOvercast = Me.SoundDesc(2).Text
      obj.AlarmOvercast = Me.CheckAlarm(2).Value
      
    Case 3
      obj.SafeDry = Me.CheckSafe(3).Value
      obj.SoundDry = Me.SoundDesc(3).Text
      obj.AlarmDry = Me.CheckAlarm(3).Value
    Case 4
      obj.SafeWet = Me.CheckSafe(4).Value
      obj.SoundWet = Me.SoundDesc(4).Text
      obj.AlarmWet = Me.CheckAlarm(4).Value
    Case 5
      obj.SafeRain = Me.CheckSafe(5).Value
      obj.SoundRain = Me.SoundDesc(5).Text
      obj.AlarmRain = Me.CheckAlarm(5).Value
      
    Case 6
      obj.SafeDark = Me.CheckSafe(6).Value
      obj.SoundDark = Me.SoundDesc(6).Text
      obj.AlarmDark = Me.CheckAlarm(6).Value
    Case 7
      obj.SafeLight = Me.CheckSafe(7).Value
      obj.SoundLight = Me.SoundDesc(7).Text
      obj.AlarmLight = Me.CheckAlarm(7).Value
    Case 8
      obj.SafeVLight = Me.CheckSafe(8).Value
      obj.SoundVLight = Me.SoundDesc(8).Text
      obj.AlarmVLight = Me.CheckAlarm(8).Value
      
  End Select
End Sub

Private Sub StopAlarm_Click()
  obj.AAG_AlarmStop
End Sub

Private Sub PlayAlarm_Click(Index As Integer)
  Select Case Index
    Case 0
      If obj.SoundClear <> "" Then
        obj.AAG_AlarmStart obj.SoundClear
      End If
    Case 1
      If obj.SoundCloudy <> "" Then
        obj.AAG_AlarmStart obj.SoundCloudy
      End If
    Case 2
      If obj.SoundOvercast <> "" Then
        obj.AAG_AlarmStart obj.SoundOvercast
      End If
    Case 3
      If obj.SoundDry <> "" Then
        obj.AAG_AlarmStart obj.SoundDry
      End If
    Case 4
      If obj.SoundWet <> "" Then
        obj.AAG_AlarmStart obj.SoundWet
      End If
    Case 5
      If obj.SoundRain <> "" Then
        obj.AAG_AlarmStart obj.SoundRain
      End If
    Case 6
      If obj.SoundDark <> "" Then
        obj.AAG_AlarmStart obj.SoundDark
      End If
    Case 7
      If obj.SoundLight <> "" Then
        obj.AAG_AlarmStart obj.SoundLight
      End If
    Case 8
      If obj.SoundVLight <> "" Then
        obj.AAG_AlarmStart obj.SoundVLight
      End If
  End Select
End Sub


