VERSION 5.00
Begin VB.Form Example2Form 
   Caption         =   "Example2"
   ClientHeight    =   5235
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   6180
   LinkTopic       =   "Form1"
   ScaleHeight     =   5235
   ScaleWidth      =   6180
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command1 
      Caption         =   "Get data"
      Height          =   315
      Left            =   60
      TabIndex        =   0
      Top             =   120
      Width           =   1305
   End
   Begin VB.Label Label2 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   11
      Left            =   4230
      TabIndex        =   40
      Top             =   3840
      Width           =   1875
   End
   Begin VB.Label Label2 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   12
      Left            =   4230
      TabIndex        =   39
      Top             =   4110
      Width           =   1875
   End
   Begin VB.Label Label2 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   2
      Left            =   4230
      TabIndex        =   38
      Top             =   1410
      Width           =   1875
   End
   Begin VB.Label Label2 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   1
      Left            =   4230
      TabIndex        =   37
      Top             =   1140
      Width           =   1875
   End
   Begin VB.Label Label2 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   0
      Left            =   4230
      TabIndex        =   36
      Top             =   870
      Width           =   1875
   End
   Begin VB.Label Hdr 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00808080&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Description"
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   2
      Left            =   4230
      TabIndex        =   35
      Top             =   600
      Width           =   1875
   End
   Begin VB.Label Hdr 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00808080&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Value"
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   1
      Left            =   2370
      TabIndex        =   34
      Top             =   600
      Width           =   1875
   End
   Begin VB.Label Hdr 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00808080&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Method / Property Name"
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   0
      Left            =   60
      TabIndex        =   33
      Top             =   600
      Width           =   2325
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   15
      Left            =   2370
      TabIndex        =   32
      Top             =   4920
      Width           =   1875
   End
   Begin VB.Label Label0 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   15
      Left            =   60
      TabIndex        =   31
      Top             =   4920
      Width           =   2325
   End
   Begin VB.Label Label0 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   14
      Left            =   60
      TabIndex        =   30
      Top             =   4650
      Width           =   2325
   End
   Begin VB.Label Label0 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   13
      Left            =   60
      TabIndex        =   29
      Top             =   4380
      Width           =   2325
   End
   Begin VB.Label Label0 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   12
      Left            =   60
      TabIndex        =   28
      Top             =   4110
      Width           =   2325
   End
   Begin VB.Label Label0 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   11
      Left            =   60
      TabIndex        =   27
      Top             =   3840
      Width           =   2325
   End
   Begin VB.Label Label0 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   10
      Left            =   60
      TabIndex        =   26
      Top             =   3570
      Width           =   2325
   End
   Begin VB.Label Label0 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   9
      Left            =   60
      TabIndex        =   25
      Top             =   3300
      Width           =   2325
   End
   Begin VB.Label Label0 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   8
      Left            =   60
      TabIndex        =   24
      Top             =   3030
      Width           =   2325
   End
   Begin VB.Label Label0 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   7
      Left            =   60
      TabIndex        =   23
      Top             =   2760
      Width           =   2325
   End
   Begin VB.Label Label0 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   6
      Left            =   60
      TabIndex        =   22
      Top             =   2490
      Width           =   2325
   End
   Begin VB.Label Label0 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   5
      Left            =   60
      TabIndex        =   21
      Top             =   2220
      Width           =   2325
   End
   Begin VB.Label Label0 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   4
      Left            =   60
      TabIndex        =   20
      Top             =   1950
      Width           =   2325
   End
   Begin VB.Label Label0 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   3
      Left            =   60
      TabIndex        =   19
      Top             =   1680
      Width           =   2325
   End
   Begin VB.Label Label0 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   2
      Left            =   60
      TabIndex        =   18
      Top             =   1410
      Width           =   2325
   End
   Begin VB.Label Label0 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   1
      Left            =   60
      TabIndex        =   17
      Top             =   1140
      Width           =   2325
   End
   Begin VB.Label Label0 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   0
      Left            =   60
      TabIndex        =   16
      Top             =   870
      Width           =   2325
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   8
      Left            =   2370
      TabIndex        =   15
      Top             =   3030
      Width           =   1875
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   9
      Left            =   2370
      TabIndex        =   14
      Top             =   3300
      Width           =   1875
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   10
      Left            =   2370
      TabIndex        =   13
      Top             =   3570
      Width           =   1875
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   11
      Left            =   2370
      TabIndex        =   12
      Top             =   3840
      Width           =   1875
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   12
      Left            =   2370
      TabIndex        =   11
      Top             =   4110
      Width           =   1875
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   13
      Left            =   2370
      TabIndex        =   10
      Top             =   4380
      Width           =   1875
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   14
      Left            =   2370
      TabIndex        =   9
      Top             =   4650
      Width           =   1875
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   7
      Left            =   2370
      TabIndex        =   8
      Top             =   2760
      Width           =   1875
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   6
      Left            =   2370
      TabIndex        =   7
      Top             =   2490
      Width           =   1875
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   5
      Left            =   2370
      TabIndex        =   6
      Top             =   2220
      Width           =   1875
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   4
      Left            =   2370
      TabIndex        =   5
      Top             =   1950
      Width           =   1875
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   3
      Left            =   2370
      TabIndex        =   4
      Top             =   1680
      Width           =   1875
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   2
      Left            =   2370
      TabIndex        =   3
      Top             =   1410
      Width           =   1875
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   1
      Left            =   2370
      TabIndex        =   2
      Top             =   1140
      Width           =   1875
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   285
      Index           =   0
      Left            =   2370
      TabIndex        =   1
      Top             =   870
      Width           =   1875
   End
End
Attribute VB_Name = "Example2Form"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private oCW

Function SwitchStatusDesc(ByVal iP) As String
  Select Case iP
    Case 0
      SwitchStatusDesc = "Unknown"
    Case 1
      SwitchStatusDesc = "Open"
    Case 2
      SwitchStatusDesc = "Close"
  End Select
End Function

Function SafeConditionDesc(ByVal iP) As String
  Select Case iP
    Case True
      SafeConditionDesc = "Safe"
    Case False
      SafeConditionDesc = "Unsafe"
  End Select
End Function

Function CloudDesc(ByVal iP) As String
  Select Case iP
    Case 0
      CloudDesc = "Unknown"
    Case 1
      CloudDesc = oCW.DescriptionClear
    Case 2
      CloudDesc = oCW.DescriptionCloudy
    Case 3
      CloudDesc = oCW.DescriptionVCloudy
  End Select
End Function

Function RainDesc(ByVal iP) As String
  Select Case iP
    Case 0
      RainDesc = "Unknown"
    Case 1
      RainDesc = oCW.DescriptionDry
    Case 2
      RainDesc = oCW.DescriptionWet
    Case 3
      RainDesc = oCW.DescriptionRain
  End Select
End Function

Function BrightnessDesc(ByVal iP) As String
  Select Case iP
    Case 0
      BrightnessDesc = "Unknown"
    Case 1
      BrightnessDesc = oCW.DescriptionDark
    Case 2
      BrightnessDesc = oCW.DescriptionLight
    Case 3
      BrightnessDesc = oCW.DescriptionVLight
  End Select
End Function


Private Sub Command1_Click()
  Me.Label0(0).Caption = "Condition_Cloud"
  Me.Label0(1).Caption = "Condition_Rain"
  Me.Label0(2).Caption = "Condition_Brightness"
  Me.Label0(3).Caption = "SkyTemperature"
  Me.Label0(4).Caption = "RainValue"
  Me.Label0(5).Caption = "BrightnessValue"
  Me.Label0(6).Caption = "AmbientTemperature"
  Me.Label0(7).Caption = "SkySensorTemperature"
  Me.Label0(8).Caption = "RainHeaterPercent"
  Me.Label0(9).Caption = "RainHeaterStatus"
  Me.Label0(10).Caption = "RainHeaterTemperature"
  Me.Label0(11).Caption = "SwitchStatus"
  Me.Label0(12).Caption = "Safe"
  Me.Label0(13).Caption = "MForm.Value_Cycle"
  Me.Label0(14).Caption = "MForm.LblRS232Errors.Caption"
  Me.Label0(15).Caption = "Lastreading"
  
  Me.Label1(0).Caption = oCW.Condition_Cloud()
  Me.Label1(1).Caption = oCW.Condition_Rain()
  Me.Label1(2).Caption = oCW.Condition_Brightness()
  Me.Label1(3).Caption = Format(oCW.SkyTemperature(), "0.0")
  Me.Label1(4).Caption = Format(oCW.RainValue(), "0")
  Me.Label1(5).Caption = Format(oCW.BrightnessValue(), "0")
  Me.Label1(6).Caption = Format(oCW.AmbientTemperature(), "0.0")
  Me.Label1(7).Caption = Format(oCW.SkySensorTemperature(), "0.0")
  Me.Label1(8).Caption = Format(Val(oCW.RainHeaterPercent()), "0")
  Me.Label1(9).Caption = oCW.RainHeaterStatus()
  Me.Label1(10).Caption = Format(oCW.RainHeaterTemperature(), "0.0")
  Me.Label1(11).Caption = oCW.SwitchStatus()
  Me.Label1(12).Caption = oCW.Safe()
  Me.Label1(13).Caption = Format(oCW.MForm.Value_Cycle(), "0.0")
  Me.Label1(14).Caption = Val(oCW.MForm.LblRS232Errors.Caption)
  Me.Label1(15).Caption = Format(oCW.lastreading, " dd.mm.yy hh:mm:ss")
  
  Me.Label2(0).Caption = CloudDesc(oCW.Condition_Cloud())
  Me.Label2(1).Caption = RainDesc(oCW.Condition_Rain())
  Me.Label2(2).Caption = BrightnessDesc(oCW.Condition_Brightness())
  Me.Label2(11).Caption = SwitchStatusDesc(oCW.SwitchStatus())
  Me.Label2(12).Caption = SafeConditionDesc(oCW.Safe())
End Sub

Private Sub Form_Load()
  Set oCW = CreateObject("AAG_CloudWatcher.CloudWatcher")
  oCW.device_start
  Do While Not oCW.DataReady()
    DoEvents
  Loop
End Sub

Private Sub Form_Unload(Cancel As Integer)
  Set oCW = Nothing
End Sub

